export const data = {
  message: "https://images.dog.ceo/breeds/bulldog-english/mami.jpg",
  status: "success",
};
